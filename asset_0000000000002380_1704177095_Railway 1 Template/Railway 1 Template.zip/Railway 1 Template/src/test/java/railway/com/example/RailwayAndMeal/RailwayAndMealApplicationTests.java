package railway.com.example.RailwayAndMeal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayAndMealApplicationTests {

	@Test
	void contextLoads() {
	}

}
